package com.example.phonostream;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class CreatePlaylist implements Initializable {
    @FXML
    private Button createPlaylistButton;
    @FXML
    private TextField playlistNameTextField;
    @FXML
    private Button addSongButton;
    @FXML
    private Button deleteSongButton;
    @FXML
    private TextField songIndexField;
    @FXML
    private ScrollPane scrollView;
    @FXML
    private VBox vBoxScroll;

    private final ArrayList<String> songNames = new ArrayList<>();
    private final ArrayList<String> songPaths = new ArrayList<>();
    private final ArrayList<Text> songTexts = new ArrayList<>();

    private int sIndex = 0;
    private int deleteSIndex;

    private final InputStream inputStream = getClass().getResourceAsStream("sett.txt");
    private File mainDirectory;

    private String osConfigDir;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        scrollView.setContent(vBoxScroll);

        String os = System.getProperty("os.name").toLowerCase();
        Path directoryPath = null;

        if (os.contains("win")) {
            String userProfile = System.getenv("USERPROFILE");
            osConfigDir = userProfile + "/AppData/Local/PhonoStream/";
        } else if (os.contains("mac")) {
            osConfigDir = System.getProperty("os.home") + "/Library/Application Support/PhonoStream/";
        } else if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
            osConfigDir = System.getenv("HOME") + "/.config/PhonoStream/";
        }

        String fileName = "";
        if (osConfigDir != null) {
            directoryPath = Paths.get(osConfigDir);
            String file = "sett.txt";
            Path filePath = directoryPath.resolve(file);
            fileName = filePath.toString();
        }

        try {
            InputStream inputStream = new FileInputStream(fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("directory")) {
                    String dir = line.substring(11);
                    if (!dir.equals("---"))
                        mainDirectory = new File(dir);
                    else
                        System.out.println("Directory not found");

                    break;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void createPlaylistCmd() throws IOException {
        if (mainDirectory == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No main directory found");
            alert.setHeaderText("No main directory found");
            alert.setContentText("Please choose a main directory - perhaps you did not Make the main directory in the files");
            alert.showAndWait();
            return;
        }

        if (playlistNameTextField.getText().trim().isEmpty() || containsSpecial(playlistNameTextField.getText())) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error - Invalid playlist name");
            alert.setHeaderText("Invalid playlist name");
            alert.setContentText("Please enter a valid playlist name");
            alert.showAndWait();
            return;
        }

        FileWriter fileWriter = new FileWriter(mainDirectory.getAbsolutePath() + File.separator + playlistNameTextField.getText() + ".txt");

        for (String song : songPaths) {
            fileWriter.write(song + "\n");
        }
        System.out.println("Content appended successfully.");
        fileWriter.close();

        Stage stage = (Stage) createPlaylistButton.getScene().getWindow();
        stage.close();
    }

    public void addSongsCmd() {
        if (playlistNameTextField.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error - No Playlist Name");
            alert.setHeaderText("No Playlist Name");
            alert.setContentText("Please enter a playlist name before adding songs");
            alert.showAndWait();
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Add Song File");

        fileChooser.setInitialDirectory(mainDirectory);
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Audio Files", "*.mp3", "*.aac", "*.ogg", "*.wav", "*.aiff", ".snd"));
        File songFile = fileChooser.showOpenDialog(null);

        if (songFile != null) {
            String songName = songFile.getName().split("\\.")[0];

            songNames.add(songName);
            songPaths.add(songFile.getAbsolutePath());
            songTexts.add(new Text(songName));

            Platform.runLater(() -> {
                vBoxScroll.getChildren().add(songTexts.get(sIndex));
                sIndex++;
            });
        }
    }

    public void deleteSongCmd() {
        if (playlistNameTextField.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error - No Playlist Name");
            alert.setHeaderText("No Playlist Name");
            alert.setContentText("Please enter a playlist name before adding songs");
            alert.showAndWait();
            return;
        }

        if (!songIndexField.getText().isEmpty()) {
            try {
                deleteSIndex = Integer.parseInt(songIndexField.getText());
                if (deleteSIndex < songNames.size()) {
                    Platform.runLater(() -> {
                        vBoxScroll.getChildren().remove(songTexts.get(deleteSIndex));
                        songNames.remove(deleteSIndex);
                        songPaths.remove(deleteSIndex);
                        songTexts.remove(deleteSIndex);
                        sIndex--;
                    });
                } else {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error - Invalid Song Index");
                alert.setHeaderText("Invalid Song Index");
                alert.setContentText("Please enter a valid song index");
                alert.showAndWait();
            }
        }
    }

    public boolean containsSpecial(String str) {
        return !str.matches("[a-zA-Z0-9_\\-]*");
    }

}
