package com.example.phonostream;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.net.URISyntaxException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class HelloApplication extends Application {
    private static String fileName;
    private static Path filePath;

    private static final Map<String, String> configMap = new HashMap<>();
    private static final Map<String, String> originalConfigMap = new HashMap<>();

    public HelloController controller;
    private static URI uri;
    private String osConfigDir;

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-view.fxml"));
        String appCss = Objects.requireNonNull(getClass().getResource("application.css")).toExternalForm();

        Scene scene = new Scene(fxmlLoader.load(), 800, 450);
        scene.getStylesheets().add(appCss);

        stage.setTitle("PhonoStream");
        stage.setScene(scene);

        stage.show();

        controller = fxmlLoader.getController();

        String os = System.getProperty("os.name").toLowerCase();
        Path directoryPath = null;

        if (os.contains("win")) {
            String userProfile = System.getenv("USERPROFILE");
            osConfigDir = userProfile + "/AppData/Local/PhonoStream/";
        } else if (os.contains("mac")) {
            osConfigDir = System.getProperty("os.home") + "/Library/Application Support/PhonoStream/";
        } else if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
            osConfigDir = System.getenv("HOME") + "/.config/PhonoStream/";
        }

        if (osConfigDir != null) {
            Path path = Paths.get(osConfigDir);
            try {
                if (!Files.exists(path)) {
                    Files.createDirectories(path);
                    System.out.println("Directory created successfully.");
                } else {
                    System.out.println("Directory already exists.");
                }
            } catch (IOException e) {
                System.err.println("Failed to create directory: " + e.getMessage());
            }

            directoryPath = Paths.get(osConfigDir);
        }

        if (directoryPath != null) {
            String file = "sett.txt";
            filePath = directoryPath.resolve(file);
            try {
                if (!Files.exists(filePath)) {
                    Files.createFile(filePath);
                    System.out.println("File created successfully.");

                    String content = "volume: 35\nstart_from_playlist: false\n" +
                            "play_on_start: false\n" +
                            "loop: false\n" +
                            "directory: ---\n" +
                            "autoplay: false\n" +
                            "default_playlist: ---\n";
                    BufferedWriter bufferedWriter = Files.newBufferedWriter(filePath);
                    bufferedWriter.write(content);
                    bufferedWriter.close();

                } else {
                    System.out.println("File already exists.");
                }
            } catch (IOException e) {
                System.err.println("Failed to create file: " + e.getMessage());
            }

            fileName = filePath.toString();
        }

        System.out.println(fileName);
        System.out.println("Hello application start");

        readConfigFile();

        stage.setOnCloseRequest(_ -> {
            for (Map.Entry<String, String> entry : originalConfigMap.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();

                if (key.equals("volume") && !value.equals(Integer.toString(controller.getVolume())))
                    updateConfigValue("volume", Integer.toString(controller.getVolume()));

                if (key.equals("directory") && !value.equals(controller.getMainDirectory()))
                    updateConfigValue("directory", controller.getMainDirectory());

                if (key.equals("autoplay") && !value.equals(Boolean.toString(controller.getAutoPlay())))
                    updateConfigValue("autoplay", Boolean.toString(controller.getAutoPlay()));

                if (key.equals("loop") && !value.equals(Boolean.toString(controller.getIsLooping())))
                    updateConfigValue("loop", Boolean.toString(controller.getIsLooping()));

                if (key.equals("play_on_start") && !value.equals(Boolean.toString(controller.getPlayOnStart())))
                    updateConfigValue("play_on_start", Boolean.toString(controller.getPlayOnStart()));

                if (key.equals("start_from_playlist") && !value.equals(Boolean.toString(controller.getStartFromPlaylist())))
                    updateConfigValue("start_from_playlist", Boolean.toString(controller.getStartFromPlaylist()));

                if (key.equals("default_playlist") && !value.equals(controller.getDefaultPlaylist()))
                    updateConfigValue("default_playlist", controller.getDefaultPlaylist());
            }

            checkAndWriteChanges();

            if (controller.getTimer() != null)
                controller.cancelTimer();
        });
    }

    public static void main(String[] args) {
        launch();
    }

    private static void readConfigFile() {
        try (InputStream inputStream = new FileInputStream(fileName);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(": ");
                if (parts.length == 2) {
                    configMap.put(parts[0], parts[1]);
                    originalConfigMap.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static void updateConfigValue(String key, String value) {
        configMap.put(key, value);
    }

    private static void checkAndWriteChanges() {
        System.out.println("fileName: " + fileName);
        if (!configMap.equals(originalConfigMap)) {
            try (BufferedWriter writer =  Files.newBufferedWriter(filePath)) {
                for (Map.Entry<String, String> entry : configMap.entrySet()) {
                    writer.write(entry.getKey() + ": " + entry.getValue());
                    writer.newLine();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            System.out.println("Changes updated successfully");
        }
    }
}