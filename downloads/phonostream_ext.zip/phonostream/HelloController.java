package com.example.phonostream;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class HelloController implements Initializable {
    @FXML
    private Button playButton;
    @FXML
    private Button resetButton;
    @FXML
    private Button loopButton;
    @FXML
    private Button previousButton;
    @FXML
    private Button nextButton;
    @FXML
    private Button muteButton;
    @FXML
    private Slider volumeSlider;
    @FXML
    private Label volumeLabel;
    @FXML
    private Label currentSongLabel;
    @FXML
    private Label nextSongLabel;
    @FXML
    private Label playlistNameLabel;
    @FXML
    private Label timeStampLabel;
    @FXML
    private ComboBox<String> speedBox;
    @FXML
    private Slider timingSlider;
    @FXML
    private CheckMenuItem autoPlayMenuItem;
    @FXML
    private CheckMenuItem playOnStartMenuItem;
    @FXML
    private CheckMenuItem loopMenuItem;
    @FXML
    private CheckMenuItem startFromPlaylistMenuItem;
    @FXML
    private MenuItem createPlaylistItem;
    @FXML
    private MenuItem editPlaylistItem;
    @FXML
    private MenuItem deletePlaylistItem;
    @FXML
    private MenuItem openPlaylistItem;

    private int prevVolume = 0;
    private int volume;

    private boolean running;
    private boolean isLooping = false;
    private boolean autoPlay = false;
    private boolean playOnStart = false;
    private boolean startFromPlaylist;

    private File mainDirectory;
    private ArrayList<File> songs;
    private File initialPlaylist;

    private int songNumber;
    private final double[] speeds = {0.25, 0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00};

    private Timer timer;

    private Media media;
    private MediaPlayer mediaPlayer;

    private final Image pauseImage = new Image(getClass().getResourceAsStream("images/pause.png"));
    private final ImageView pauseImageView = new ImageView(pauseImage);

    private final Image playImage = new Image(getClass().getResourceAsStream("images/play-button-arrowhead.png"));
    private final ImageView playImageView = new ImageView(playImage);

    private final Image loopImage = new Image(getClass().getResourceAsStream("images/loop.png"));
    private final ImageView loopImageView = new ImageView(loopImage);

    private final Image resetImage = new Image(getClass().getResourceAsStream("images/reset.png"));
    private final ImageView resetImageView = new ImageView(resetImage);

    private final Image nextImage = new Image(getClass().getResourceAsStream("images/right.png"));
    private final ImageView nextImageView = new ImageView(nextImage);

    private final Image previousImage = new Image(getClass().getResourceAsStream("images/left.png"));
    private final ImageView previousImageView = new ImageView(previousImage);

    private final Image muteImage = new Image(getClass().getResourceAsStream("images/volume-mute.png"));
    private final ImageView muteImageView = new ImageView(muteImage);

    private final Image lowVolumeImage = new Image(getClass().getResourceAsStream("images/low-volume.png"));
    private final ImageView lowVolumeImageView = new ImageView(lowVolumeImage);

    private final Image mediumVolumeImage = new Image(getClass().getResourceAsStream("images/medium-volume.png"));
    private final ImageView mediumVolumeImageView = new ImageView(mediumVolumeImage);

    private final Image settingsImage = new Image(getClass().getResourceAsStream("images/settings.png"));
    private final ImageView settingsImageView = new ImageView(settingsImage);

    private final Image folderImage = new Image(getClass().getResourceAsStream("images/folder.png"));
    private final ImageView folderImageView = new ImageView(folderImage);

    private final Image noLoopImage = new Image(getClass().getResourceAsStream("images/noloop.png"));
    private final ImageView noLoopImageView = new ImageView(noLoopImage);

    private String osConfigDir;
    private String fileName;
    private Path filePath;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String os = System.getProperty("os.name").toLowerCase();
        Path directoryPath = null;

        if (os.contains("win")) {
            String userProfile = System.getenv("USERPROFILE");
            osConfigDir = userProfile + "/AppData/Local/PhonoStream/";
        } else if (os.contains("mac")) {
            osConfigDir = System.getProperty("os.home") + "/Library/Application Support/PhonoStream/";
        } else if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
            osConfigDir = System.getenv("HOME") + "/.config/PhonoStream/";
        }

        if (osConfigDir != null) {
            Path path = Paths.get(osConfigDir);
            try {
                if (!Files.exists(path)) {
                    Files.createDirectories(path);
                    System.out.println("Directory created successfully.");
                } else {
                    System.out.println("Directory already exists.");
                }
            } catch (IOException e) {
                System.err.println("Failed to create directory: " + e.getMessage());
            }

            directoryPath = Paths.get(osConfigDir);
        }

        if (directoryPath != null) {
            String file = "sett.txt";
            filePath = directoryPath.resolve(file);
            try {
                if (!Files.exists(filePath)) {
                    Files.createFile(filePath);
                    System.out.println("File created successfully.");

                    String content = """
                            volume: 35
                            start_from_playlist: false
                            play_on_start: false
                            loop: false
                            directory: ---
                            autoplay: false
                            default_playlist: ---
                            """;
                    BufferedWriter bufferedWriter = Files.newBufferedWriter(filePath);
                    bufferedWriter.write(content);
                    bufferedWriter.close();

                } else {
                    System.out.println("File already exists.");
                }
            } catch (IOException e) {
                System.err.println("Failed to create file: " + e.getMessage());
            }

            fileName = filePath.toString();
        }

        System.out.println(fileName);

        changeImageDimensions(pauseImageView);
        changeImageDimensions(playImageView);
        changeImageDimensions(loopImageView);
        changeImageDimensions(resetImageView);
        changeImageDimensions(nextImageView);
        changeImageDimensions(previousImageView);
        changeImageDimensions(muteImageView);
        changeImageDimensions(lowVolumeImageView);
        changeImageDimensions(mediumVolumeImageView);
        changeImageDimensions(settingsImageView);
        changeImageDimensions(folderImageView);
        changeImageDimensions(noLoopImageView);

        resetButton.setGraphic(resetImageView);
        loopButton.setGraphic(noLoopImageView);
        previousButton.setGraphic(previousImageView);
        nextButton.setGraphic(nextImageView);

        for (double speed : speeds) {
            speedBox.getItems().add(speed + "x");
        }

        try {
            InputStream inputStream = new FileInputStream(fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = br.readLine()) != null) {
               if (line.startsWith("volume")) {
                   String vol = line.substring(8);
                   volume = Integer.parseInt(vol);
               } else if (line.startsWith("directory")) {
                   String dir = line.substring(11);
                   if (!dir.equals("---"))
                       mainDirectory = new File(dir);
                   else
                       System.out.println("Directory not found");
               } else if (line.startsWith("autoplay")) {
                   String autoplay = line.substring(10);
                   autoPlay = Boolean.parseBoolean(autoplay);
               } else if (line.startsWith("loop")) {
                   String loop = line.substring(6);
                   isLooping = Boolean.parseBoolean(loop);
               } else if (line.startsWith("play_on_start")) {
                   String playOnStartStr = line.substring(15);
                   playOnStart = Boolean.parseBoolean(playOnStartStr);
               } else if (line.startsWith("start_from_playlist")) {
                   String startPlaylist = line.substring(21);
                   startFromPlaylist = Boolean.parseBoolean(startPlaylist);
               } else if (line.startsWith("default_playlist")) {
                   String defaultPlaylist = line.substring(18);
                   if (defaultPlaylist.equals("---")) {
                       initialPlaylist = null;
                       System.out.println("Default playlist not found");
                   } else {
                       initialPlaylist = new File(defaultPlaylist);
                       System.out.println("Default playlist: " + initialPlaylist);
                   }
               }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        autoPlayMenuItem.setSelected(autoPlay);
        loopMenuItem.setSelected(isLooping);
        playOnStartMenuItem.setSelected(playOnStart);
        startFromPlaylistMenuItem.setSelected(startFromPlaylist);

        running = playOnStart;

        if (running)
            playButton.setGraphic(pauseImageView);
        else
            playButton.setGraphic(playImageView);

        if (volume == 0) {
            muteButton.setGraphic(muteImageView);
        } else if (volume < 50) {
            muteButton.setGraphic(lowVolumeImageView);
        } else {
            muteButton.setGraphic(mediumVolumeImageView);
        }

        if (startFromPlaylist && initialPlaylist != null) {
            try {
                if (initialPlaylist.exists()) {
                    initSongsFromPlaylist();
                } else if (mainDirectory != null) {
                    initSongs();
                }
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        } else if (startFromPlaylist || mainDirectory != null) {
            initSongs();
        }

        volumeSlider.setValue(volume);

        if (mediaPlayer != null)
            mediaPlayer.setVolume(volume * 0.01);
        volumeLabel.setText(volume + "%");

        volumeSlider.valueProperty().addListener((_, _, _) -> setVolumeFromSlider());
    }

    private void changeImageDimensions(ImageView imageView) {
        int imageWidth = 35;
        int imageHeight = 35;

        imageView.setFitWidth(imageWidth);
        imageView.setFitHeight(imageHeight);
    }

    private boolean correctFormat(String fileName) {
        return fileName.endsWith(".mp3") || fileName.endsWith(".acc") || fileName.endsWith(".wav") || fileName.endsWith(".ogg") || fileName.endsWith(".aiff") || fileName.endsWith(".snd");
    }

    public static String formatDuration(double seconds) {
        int minutes = (int) (seconds / 60);
        int remainingSeconds = (int) (seconds % 60);
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void initSongs() {
        songNumber = 0;

        if (mainDirectory == null)
            return;

        songs = new ArrayList<>();
        File[] files = mainDirectory.listFiles();

        if (files != null) {
            for (File file : files) {
                System.out.println(file.getName());
                if (correctFormat(file.getName())) {
                    songs.add(file);
                }
            }
        }

        playlistNameLabel.setText("None");

        media = new Media(songs.get(songNumber).toURI().toString());
        mediaPlayer = new MediaPlayer(media);

        setSongNameAndPlay();
    }

    private void initSongsFromPlaylist() throws FileNotFoundException {
        songNumber = 0;

        if (songs == null)
            songs = new ArrayList<>();
        else {
            songs.clear();
            mediaPlayer.pause();
        }

        FileReader fileReader = new FileReader(initialPlaylist);
        try (BufferedReader reader = new BufferedReader(fileReader)) {
            String line;
            while ((line = reader.readLine()) != null) {
                songs.add(new File(line));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        playlistNameLabel.setText(initialPlaylist.getName().split("\\.")[0]);

        media = new Media(songs.get(songNumber).toURI().toString());
        mediaPlayer = new MediaPlayer(media);

        setSongNameAndPlay();
    }

    private void setSongNameAndPlay() {
        String songNameShort = songs.get(songNumber).getName().split("\\.")[0];
        currentSongLabel.setText(songNameShort);

        if (songs.size() > songNumber + 1) {
            String nextNameShort = songs.get(songNumber + 1).getName().split("\\.")[0];
            nextSongLabel.setText(nextNameShort);
        } else {
            nextSongLabel.setText("None");
        }

        timingSlider.setMin(0.0);
        timingSlider.setMax(media.getDuration().toSeconds());

        if (running) {
            mediaPlayer.play();
            beginTimer();
        }
    }

    private void setVolumeFromSlider() {
        volume = (int) volumeSlider.getValue();

        if (mediaPlayer != null)
            mediaPlayer.setVolume(volume * 0.01);

        volumeLabel.setText(volume + "%");

        if (volume == 0) {
            muteButton.setGraphic(muteImageView);
        } else if (volume < 50) {
            muteButton.setGraphic(lowVolumeImageView);
        } else {
            muteButton.setGraphic(mediumVolumeImageView);
        }
    }

    public void playPause() {
        if (mediaPlayer == null)
            return;

        if (!running) {
            beginTimer();
            mediaPlayer.play();
            running = true;
            playButton.setGraphic(pauseImageView);
        } else {
            cancelTimer();
            mediaPlayer.pause();
            running = false;
            playButton.setGraphic(playImageView);
        }
    }

    public void reset() {
        if (mediaPlayer == null)
            return;

        mediaPlayer.seek(Duration.seconds(0));
    }

    public void setLoop() {
        if (isLooping) {
            isLooping = false;
            loopButton.setGraphic(noLoopImageView);
        } else {
            isLooping = true;
            loopButton.setGraphic(loopImageView);
        }
    }

    public void goToPrevious() {
        if (mediaPlayer == null)
            return;

        if (songNumber > 0) {
            songNumber--;

            String nextNameShort;
            if (songs.size() > 1) {
                nextNameShort = songs.get(songNumber + 1).getName().split("\\.")[0];
                nextSongLabel.setText(nextNameShort);
            } else {
                nextNameShort = songs.getFirst().getName().split("\\.")[0];
            }
            nextSongLabel.setText(nextNameShort);

            changeSong();
        } else {
            songNumber = songs.size() - 1;

            if (songs.size() > 1) {
                String nextNameShort = songs.getFirst().getName().split("\\.")[0];
                nextSongLabel.setText(nextNameShort);
            }

            changeSong();
        }

        cancelTimer();
        beginTimer();
    }

    public void goToNext() {
        if (mediaPlayer == null)
            return;

        if (songNumber < songs.size() - 1) {
            songNumber++;
            changeSong();

            String nextNameShort;
            if (songNumber <= songs.size() - 2) {
                nextNameShort = songs.get(songNumber + 1).getName().split("\\.")[0];
            } else {
                nextNameShort = songs.getFirst().getName().split("\\.")[0];
            }
            nextSongLabel.setText(nextNameShort);

        } else {
            songNumber = 0;

            if (songs.size() > 1) {
                String nextNameShort = songs.get(songNumber + 1).getName().split("\\.")[0];
                nextSongLabel.setText(nextNameShort);
            } else {
                nextSongLabel.setText("None");
            }

            changeSong();
        }

        cancelTimer();
        beginTimer();
    }

    private void changeSong() {
        if (mediaPlayer == null)
            return;

        mediaPlayer.stop();

        media = new Media(songs.get(songNumber).toURI().toString());
        mediaPlayer = new MediaPlayer(media);

        String songNameShort = songs.get(songNumber).getName().split("\\.")[0];
        currentSongLabel.setText(songNameShort);

        changeSpeed();
        mediaPlayer.setVolume(volume * 0.01);

        timingSlider.setValue(0);

        if (running)
            mediaPlayer.play();
    }

    public void muteVolume() {
        if (mediaPlayer == null)
            return;

        if (prevVolume == 0) {
            prevVolume = volume;
            volume = 0;
            mediaPlayer.setVolume(volume);
            muteButton.setGraphic(muteImageView);
        } else {
            volume = prevVolume;
            prevVolume = 0;
            mediaPlayer.setVolume(volume * 0.01);
            if (volume == 0) {
                muteButton.setGraphic(muteImageView);
            } else if (volume < 50) {
                muteButton.setGraphic(lowVolumeImageView);
            } else {
                muteButton.setGraphic(mediumVolumeImageView);
            }
        }
    }

    public void changeSpeed() {
        if (mediaPlayer == null)
            return;

        String value = speedBox.getValue();

        if (value == null) {
            mediaPlayer.setRate(1.0);
            return;
        }

        mediaPlayer.setRate(Double.parseDouble(value.substring(0, value.length() - 1)));
    }

    public void chooseMainDirectory() {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File directory = directoryChooser.showDialog(null);

        if (directory != null) {
            System.out.println("file that was received: " + directory.getAbsolutePath());
            mainDirectory = new File(directory.getAbsolutePath());
        }

        initSongs();
    }

    public void setMainDirectoryInFile() throws URISyntaxException {
        if (mainDirectory == null)
            return;

        URI uri = Objects.requireNonNull(HelloApplication.class.getResource("sett.txt")).toURI();
        String settingsFileName = Paths.get(uri).toString();

        final Map<String, String> configMap = getStringStringMap(settingsFileName);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(settingsFileName))) {
            for (Map.Entry<String, String> entry : configMap.entrySet()) {
                writer.write(entry.getKey() + ": " + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private Map<String, String> getStringStringMap(String settingsFileName) {
        final Map<String, String> configMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(settingsFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(": ");
                if (parts.length == 2) {
                    configMap.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        configMap.put("directory", mainDirectory.getAbsolutePath());
        return configMap;
    }

    public void beginTimer() {
        timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                running = true;

                double current = 0;
                try {
                    current = mediaPlayer.getCurrentTime().toSeconds();
                } catch (NullPointerException e) {
                    Stage stage = (Stage) playButton.getScene().getWindow();
                    stage.close();
                }

                double end = media.getDuration().toSeconds();

                double finalCurrent = current;
                double finalCurrent1 = current;
                Platform.runLater(() -> {
                    timingSlider.setMin(0);
                    timingSlider.setMax(end);
                    timingSlider.setValue(finalCurrent1);

                    if (!Double.isNaN(end))
                        timeStampLabel.setText(formatDuration(finalCurrent) + "/" + formatDuration(end));
                    else
                        timeStampLabel.setText("00.00/00.00");

                    if (finalCurrent / end == 1) {
                        if (isLooping) {
                            reset();
                            timingSlider.setValue(0);
                        } else if (autoPlay) {
                            goToNext();
                        } else {
                            cancelTimer();
                        }
                    }
                });
            }
        };

        timer.scheduleAtFixedRate(timerTask, 0, 1000);
    }

    public void cancelTimer() {
        running = false;
        timer.cancel();
    }

    public void changeTimer() {
        if (mediaPlayer == null)
            return;

        mediaPlayer.seek(Duration.seconds(timingSlider.getValue()));
    }

    public void toggleAutoPlaySetting() {
        autoPlay = autoPlayMenuItem.isSelected();
    }

    public void togglePermLoopSetting() {
        isLooping = loopMenuItem.isSelected();

        if (isLooping)
            loopButton.setGraphic(loopImageView);
        else
            loopButton.setGraphic(noLoopImageView);
    }

    public void playOnStartSetting() {
        playOnStart = playOnStartMenuItem.isSelected();
    }

    public void startFromPlaylistSet() {
        startFromPlaylist = startFromPlaylistMenuItem.isSelected();
    }

    public void createNewPlaylist() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("create-playlist.fxml"));
        Stage popupWindow = loadPopup(fxmlLoader);
        popupWindow.setTitle("Create Playlist - PopUp");
        popupWindow.showAndWait();
    }

    public void editPlaylist() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("edit-playlist.fxml"));
        Stage popupWindow = loadPopup(fxmlLoader);
        popupWindow.setTitle("Edit Playlist - PopUp");
        popupWindow.showAndWait();
    }

    public void deletePlaylist() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("delete-playlist.fxml"));
        Stage popupWindow = loadPopup(fxmlLoader);
        popupWindow.setTitle("Delete Playlist - PopUp");
        popupWindow.showAndWait();
    }

    private Stage loadPopup(FXMLLoader fxmlLoader) throws IOException {
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        String popupCss = Objects.requireNonNull(getClass().getResource("popup.css")).toExternalForm();
        scene.getStylesheets().add(popupCss);

        Stage popupWindow = new Stage();
        popupWindow.setScene(scene);
        popupWindow.initModality(Modality.APPLICATION_MODAL);

        return popupWindow;
    }

    public void openPlaylist() throws FileNotFoundException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Playlist");
        fileChooser.setInitialDirectory(mainDirectory);
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text File", "*.txt"));
        File file = fileChooser.showOpenDialog(null);

        if (file != null) {
            initialPlaylist = new File(file.getAbsolutePath());
            cancelTimer();
            initSongsFromPlaylist();
        }
    }

    public int getVolume() {
        return volume;
    }

    public String getMainDirectory() {
        if (mainDirectory != null)
            return mainDirectory.getAbsolutePath();

        return "---";
    }

    public boolean getAutoPlay() {
        return autoPlay;
    }

    public boolean getIsLooping() {
        return isLooping;
    }

    public boolean getPlayOnStart() {
        return playOnStart;
    }

    public boolean getStartFromPlaylist() {
        return startFromPlaylist;
    }

    public String getDefaultPlaylist() {
        if (initialPlaylist != null)
            return initialPlaylist.getAbsolutePath();

        return "---";
    }

    public Timer getTimer() {
        return timer;
    }
}