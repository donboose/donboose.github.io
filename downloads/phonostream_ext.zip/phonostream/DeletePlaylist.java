package com.example.phonostream;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ResourceBundle;

public class DeletePlaylist implements Initializable {
    @FXML
    private Button choosePlaylistButton;
    @FXML
    private Button deletePermanentButton;
    @FXML
    private Label playlistNameLabel;

    private File mainDirectory;
    private File file;

    private String osConfigDir;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String os = System.getProperty("os.name").toLowerCase();
        Path directoryPath = null;

        if (os.contains("win")) {
            String userProfile = System.getenv("USERPROFILE");
            osConfigDir = userProfile + "/AppData/Local/PhonoStream/";
        } else if (os.contains("mac")) {
            osConfigDir = System.getProperty("os.home") + "/Library/Application Support/PhonoStream/";
        } else if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
            osConfigDir = System.getenv("HOME") + "/.config/PhonoStream/";
        }

        String fileName = "";
        if (osConfigDir != null) {
            directoryPath = Paths.get(osConfigDir);
            String file = "sett.txt";
            Path filePath = directoryPath.resolve(file);
            fileName = filePath.toString();
        }

        try {
            InputStream inputStream = new FileInputStream(fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("directory")) {
                    String dir = line.substring(11);
                    if (!dir.equals("---"))
                        mainDirectory = new File(dir);
                    else
                        System.out.println("Directory not found");

                    break;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void choosePlaylist() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Playlist File");
        fileChooser.setInitialDirectory(mainDirectory);
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        file = fileChooser.showOpenDialog(null);

        if (file != null) {
            playlistNameLabel.setText(file.getName().split("\\.")[0]);
        }
    }

    public void deleteCmd() {
        if (file == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Playlist file not chosen");
            alert.setContentText("Playlist file not chosen - please choose a playlist file");
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Playlist");
        alert.setHeaderText("Are you sure you want to delete this playlist?");
        alert.setContentText("Are you sure you want to delete the playlist " + playlistNameLabel.getText() +  "? It will be permanently deleted");

        if (alert.showAndWait().get() == ButtonType.OK) {
            if (file.exists()) {
                if (file.delete()) {
                    System.out.println("File deleted successfully.");
                } else {
                    System.out.println("Failed to delete the file.");
                }
            } else {
                System.out.println("File does not exist.");
            }

            Stage stage = (Stage) choosePlaylistButton.getScene().getWindow();
            stage.close();
        }
    }
}
