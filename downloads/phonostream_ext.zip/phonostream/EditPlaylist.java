package com.example.phonostream;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class EditPlaylist implements Initializable {
    @FXML
    private Button choosePlaylistButton;
    @FXML
    private Button addSongButton;
    @FXML
    private Button deleteSongButton;
    @FXML
    private Button applyButton;
    @FXML
    private Label playlistNameLabel;
    @FXML
    private TextField songIndexTextField;
    @FXML
    private ScrollPane scrollView;
    @FXML
    private VBox vBoxScroll;

    private File mainDirectory;
    private File playlistFile;

    String s = FileSystems.getDefault().getSeparator();

    private int sIndex = 0;
    private int deleteSIndex = 0;

    private final ArrayList<String> songPaths = new ArrayList<>();
    private final ArrayList<String> songNames = new ArrayList<>();
    private final ArrayList<Text> songTexts = new ArrayList<>();

    private String osConfigDir;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        scrollView.setContent(vBoxScroll);
    }

    public void getPlaylist() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Playlist File");

        String os = System.getProperty("os.name").toLowerCase();
        Path directoryPath = null;

        if (os.contains("win")) {
            String userProfile = System.getenv("USERPROFILE");
            osConfigDir = userProfile + "/AppData/Local/PhonoStream/";
        } else if (os.contains("mac")) {
            osConfigDir = System.getProperty("os.home") + "/Library/Application Support/PhonoStream/";
        } else if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
            osConfigDir = System.getenv("HOME") + "/.config/PhonoStream/";
        }

        String fileName = "";
        if (osConfigDir != null) {
            directoryPath = Paths.get(osConfigDir);
            String file = "sett.txt";
            Path filePath = directoryPath.resolve(file);
            fileName = filePath.toString();
        }

        try {
            InputStream inputStream = new FileInputStream(fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("directory")) {
                    String dir = line.substring(11);
                    if (!dir.equals("---"))
                        mainDirectory = new File(dir);
                    else
                        System.out.println("Directory not found");

                    break;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        fileChooser.setInitialDirectory(new File(mainDirectory.getAbsolutePath()));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        playlistFile = fileChooser.showOpenDialog(null);

        if (playlistFile != null) {
            playlistNameLabel.setText("Playlist: " + playlistFile.getName().replace(".txt", ""));

            try (BufferedReader bufferedReader = new BufferedReader(new FileReader(playlistFile))) {
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    if (correctFormat(line)) {
                        songPaths.add(line);
                        String[] broken = line.split(s);
                        songNames.add(broken[broken.length - 1].split("\\.")[0]);
                        songTexts.add(new Text(broken[broken.length - 1].split("\\.")[0]));
                    }
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            Platform.runLater(() -> {
                for (Text songText : songTexts) {
                    vBoxScroll.getChildren().add(songText);
                    sIndex++;
                }
            });
        }
    }

    public void addSongCmd() {
        if (playlistFile == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Playlist file not chosen");
            alert.setContentText("Playlist file not chosen - please choose a playlist file");
            alert.showAndWait();
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Add Song");
        fileChooser.setInitialDirectory(mainDirectory);
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Audio Files", "*.mp3", "*.aac", "*.ogg", "*.wav", "*.aiff", ".snd"));
        File songFile = fileChooser.showOpenDialog(null);

        if (songFile != null) {
            String songName = songFile.getName().split("\\.")[0];

            songNames.add(songName);
            songPaths.add(songFile.getAbsolutePath());
            songTexts.add(new Text(songName));

            Platform.runLater(() -> {
                vBoxScroll.getChildren().add(songTexts.get(sIndex));
                sIndex++;
            });
        }
    }

    public void deleteSongCmd() {
        if (playlistFile == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Playlist file not chosen");
            alert.setContentText("Playlist file not chosen - please choose a playlist file");
            alert.showAndWait();
            return;
        }

        if (!songIndexTextField.getText().isEmpty()) {
            try {
                deleteSIndex = Integer.parseInt(songIndexTextField.getText());

                if (deleteSIndex < songNames.size()) {
                    Platform.runLater(() -> {
                        vBoxScroll.getChildren().remove(songTexts.get(deleteSIndex));
                        songNames.remove(deleteSIndex);
                        songPaths.remove(deleteSIndex);
                        songTexts.remove(deleteSIndex);
                        sIndex--;
                    });
                } else {
                    throw new NumberFormatException();
                }

            } catch (NumberFormatException e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error - Invalid Song Index");
                alert.setHeaderText("Invalid Song Index");
                alert.setContentText("Please enter a valid song index");
                alert.showAndWait();
            }
        }
    }

    public void applyChanges() throws IOException {
        if (playlistFile == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Playlist file not chosen");
            alert.setContentText("Playlist file not chosen - please choose a playlist file");
            alert.showAndWait();
            return;
        }

        FileWriter fileWriter = new FileWriter(playlistFile);

        for (String songPath : songPaths) {
            fileWriter.write(songPath + "\n");
        }

        fileWriter.close();

        Stage stage = (Stage) addSongButton.getScene().getWindow();
        stage.close();
    }

    private boolean correctFormat(String fileName) {
        return fileName.endsWith(".mp3") || fileName.endsWith(".acc") || fileName.endsWith(".wav") || fileName.endsWith(".ogg") || fileName.endsWith(".aiff") || fileName.endsWith(".snd");
    }
}
